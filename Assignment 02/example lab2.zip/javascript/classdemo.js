const fullName =  prompt("What's your name: ");
const totalTickets =  Number(prompt("How many tickets do you need: "));
const age =  Number(prompt("What is minimum age in your group: "));
let resultMessage ='';
const ticketPrice = 20;
const miniAge = 18;
const taxRate = 0.12;
//locate all nodes
orderSummaryElem = document.getElementById("orderSummary");
userNameElem = document.getElementById('user-name');
userAgeElem = document.getElementById('user-age');
miniAgeElem = document.getElementById('mini-age');
ticketNumbersElem = document.getElementById('number-tickets');
resultElem = document.getElementById('result');

//check your group mini age 

if(age >=18){
    resultMessage=`You total amount is $${totalTickets*ticketPrice*(1+taxRate)}. Enjory your show!`
}else{
    resultMessage=`You are ${age} years old and that's not old enought to attend this show. Too bad, kiddo!`
}

orderSummaryElem.innerHTML=`Hello ${fullName}, Welcome!`;
userNameElem.innerHTML=`<strong>Name</strong>: ${fullName}`;
userAgeElem.innerHTML=`<strong>Age</strong>: ${age}`;
miniAgeElem.innerHTML=`<strong>Minimum age</strong>: ${miniAge}`
ticketNumbersElem.innerHTML=`<strong>Ticket Qty</strong>: ${totalTickets}`;
resultElem.innerHTML = resultMessage;